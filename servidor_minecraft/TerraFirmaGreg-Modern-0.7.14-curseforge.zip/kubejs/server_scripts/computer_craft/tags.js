// priority: 0

const registerComputerCraftItemTags = (event) => {
    // Nothing here for now :)
}

const registerComputerCraftBlockTags = (event) => {
    event.add('computercraft:turtle_hoe_harvestable', '#tfc:mineable_with_sharp_tool')
}