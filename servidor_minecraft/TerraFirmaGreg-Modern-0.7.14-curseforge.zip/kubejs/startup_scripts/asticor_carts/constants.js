// priority: 0

global.ASTICOR_CARTS_DISABLED_ITEMS = [
    'astikorcarts:animal_cart', 
    'astikorcarts:supply_cart', 
    'astikorcarts:plow', 
    'astikorcarts:wheel'
];