// priority: 0

global.CHISEL_AND_BITS_DISABLED_ITEMS = [
    'chiselsandbits:block_bit',
    'chiselsandbits:chiseled_block',

    'chiselsandbits:chisel_stone',
    'chiselsandbits:chisel_iron',
    'chiselsandbits:chisel_gold',
    'chiselsandbits:chisel_netherite',

    'chiselsandbits:bit_bag_dyed',
    'chiselsandbits:pattern_single_use', 
    'chiselsandbits:pattern_multi_use', 
    'chiselsandbits:monocle'
];