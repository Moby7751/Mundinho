// priority: 0

global.COMPUTER_CRAFT_DISCS = [
    '{Color:15790320}',
    '{Color:15905331}',
    '{Color:15040472}',
    '{Color:10072818}',
    '{Color:14605932}',
    '{Color:8375321}',
    '{Color:15905484}',
    '{Color:5000268}',
    '{Color:10066329}',
    '{Color:5020082}',
    '{Color:11691749}',
    '{Color:3368652}',
    '{Color:8349260}',
    '{Color:5744206}',
    '{Color:13388876}',
    '{Color:1118481}',
]