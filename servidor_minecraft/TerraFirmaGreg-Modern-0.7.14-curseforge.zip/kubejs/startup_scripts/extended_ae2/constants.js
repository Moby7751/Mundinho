global.EXTENDED_AE2_DISABLED_ITEMS = [

    'expatternprovider:infinity_cell',
    'expatternprovider:fishbig',
    'expatternprovider:pattern_provider_upgrade',
    'expatternprovider:interface_upgrade',
    'expatternprovider:io_bus_upgrade',
    'expatternprovider:pattern_terminal_upgrade',
    'expatternprovider:drive_upgrade',
    'expatternprovider:ex_inscriber',
    'expatternprovider:crystal_fixer',

    //в будущем будет крафт
    /*
    'expatternprovider:ex_charger',
    'expatternprovider:caner',
    'expatternprovider:ex_io_port',
    'expatternprovider:wireless_tool',
    'expatternprovider:wireless_connect',
    'expatternprovider:active_formation_plane',
    'expatternprovider:wireless_ex_pat',
    'expatternprovider:pattern_modifier',
    'expatternprovider:threshold_level_emitter',

    'expatternprovider:ex_export_bus_part',
    'expatternprovider:ex_import_bus_part',
    'expatternprovider:ex_pattern_access_part',
    'expatternprovider:me_packing_tape',
    'expatternprovider:tag_storage_bus',
    'expatternprovider:tag_export_bus',
    'expatternprovider:mod_storage_bus',
    'expatternprovider:mod_export_bus',
    'expatternprovider:precise_export_bus',
    'expatternprovider:ingredient_buffer',
    'expatternprovider:ex_drive',
    'expatternprovider:ex_molecular_assembler',
    
    */
]