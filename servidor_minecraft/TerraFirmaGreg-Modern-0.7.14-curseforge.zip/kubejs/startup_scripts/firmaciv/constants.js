// priority: 0

/**
 * Список хранит предметы, 
 * у которых должны быть удалены тэги и они должны быть скрыты в REI.
 */
global.FIRMACIV_DISABLED_ITEMS = [
    'firmaciv:copper_bolt'
];