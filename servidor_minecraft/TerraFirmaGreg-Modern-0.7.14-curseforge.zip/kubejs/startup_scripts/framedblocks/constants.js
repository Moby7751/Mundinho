// priority: 0

global.FRAMEDBLOCKS_DISABLED_ITEMS = [
    'framedblocks:framed_soul_torch',
    'framedblocks:framed_torch'
];