// priority: 0

/**
 * Список хранит предметы, 
 * у которых должны быть удалены тэги и они должны быть скрыты в REI.
 */
global.FTB_QUESTS_DISABLED_ITEMS = [
    'ftbquests:screen_7', 
    'ftbquests:screen_5', 
    'ftbquests:screen_3', 
    'ftbquests:screen_1', 
    'ftbquests:loot_crate_opener', 
    'ftbquests:task_screen_configurator', 
    'ftbquests:book', 
    'ftbfiltersystem:smart_filter', 
    'ftbquests:stage_barrier', 
    'ftbquests:barrier', 
    'ftbquests:custom_icon', 
    'ftbquests:missing_item', 
    'ftbquests:lootcrate'
];

