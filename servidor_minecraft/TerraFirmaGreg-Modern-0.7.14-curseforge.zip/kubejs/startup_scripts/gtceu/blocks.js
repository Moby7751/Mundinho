// priority: 0

const registerGTCEuBlocks = (event) => {
    
}