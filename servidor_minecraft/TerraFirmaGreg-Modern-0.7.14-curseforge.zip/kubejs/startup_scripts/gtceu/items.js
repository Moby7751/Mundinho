// priority: 0

const registerGTCEuItems = (event) => {
    event.create('tfg:unfinished_vacuum_tube', 'create:sequenced_assembly')
    event.create('tfg:unfinished_basic_electronic_circuit', 'create:sequenced_assembly')
}