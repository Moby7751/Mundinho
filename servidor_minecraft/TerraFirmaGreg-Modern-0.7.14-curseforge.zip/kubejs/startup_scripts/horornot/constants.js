// priority: 0

global.HOT_OR_NOT_DISABLED_ITEMS = [
    'tfchotornot:tong_part/cast_iron', 
    'tfchotornot:tongs/cast_iron'
];

