// priority: 0

global.MEGA_CELLS_DISABLED_ITEMS = [
    'megacells:sky_steel_block',
    'megacells:sky_steel_ingot',

    'megacells:decompression_module',
    'megacells:bulk_item_cell',
    'megacells:bulk_cell_component',
    'megacells:compression_card',

    'megacells:cell_component_16m',
    'megacells:cell_component_64m',
    'megacells:cell_component_256m',

    'megacells:item_storage_cell_16m',
    'megacells:item_storage_cell_64m',
    'megacells:item_storage_cell_256m',

    'megacells:fluid_storage_cell_16m',
    'megacells:fluid_storage_cell_64m',
    'megacells:fluid_storage_cell_256m',

    'megacells:portable_item_cell_16m',
    'megacells:portable_item_cell_64m',
    'megacells:portable_item_cell_256m',
,
    'megacells:portable_fluid_cell_16m',
    'megacells:portable_fluid_cell_64m',
    'megacells:portable_fluid_cell_256m',

    'megacells:16m_crafting_storage',
    'megacells:64m_crafting_storage',
    'megacells:256m_crafting_storage',

]