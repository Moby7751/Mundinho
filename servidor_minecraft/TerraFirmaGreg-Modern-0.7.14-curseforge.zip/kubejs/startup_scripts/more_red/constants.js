// priority: 0

global.MORE_RED_DISABLED_ITEMS = [
    'jumbofurnace:jumbo_furnace',
    'jumbofurnace:jumbo_furnace_jei',
    
    'morered:stone_plate', 
    'morered:soldering_table', 
    'morered:red_alloy_ingot'
];